#
#   src/tmdb.py
#
import os
import requests
import urllib


#
#   auth.
#
def auth():

    # auth request token request.
    r1 = requests.get(
        f"{os.getenv('TMDB_API_HOST')}/3/authentication/token/new?api_key={os.getenv('TMDB_API_KEY')}"
    )
    if r1.status_code != 200:
        raise Exception('auth failed: unable to fetch request token')
    request_token = r1.json()['request_token']

    # auth request token validate request.
    r2 = requests.post(
        f"{os.getenv('TMDB_API_HOST')}/3/authentication/token/validate_with_login?api_key={os.getenv('TMDB_API_KEY')}",
        json = { 
            "username"      : os.getenv('TMDB_USERNAME'),
            "password"      : os.getenv('TMDB_PASSWORD'),
            "request_token" : request_token 
        }
    )
    if r2.status_code != 200:
        raise Exception('auth failed: unable to fetch session id')
    request_token = r2.json()['request_token']

    # auth session id request.
    r3 = requests.post(
        f"https://api.themoviedb.org/3/authentication/session/new?api_key={os.getenv('TMDB_API_KEY')}",
        json = {
            "request_token" : request_token 
        }
    )
    if r3.status_code != 200:
        raise Exception('auth failed: unable to fetch session id')
    session_id = r3.json()['session_id']

    # return.
    return session_id


#
#   add.
#
def add_movie_to_list(list_id, movie_id, session_id):

    # add movie to list.
    r = requests.post(
        f"{os.getenv('TMDB_API_HOST')}/3/list/{list_id}/add_item?api_key={os.getenv('TMDB_API_KEY')}&session_id={session_id}",
        json = { "media_id" : movie_id }
    )

    # add movie to list return.
    if r.status_code == 201:
        return True
    else:
        return False


#
#   search.
#
def search_movie(title):

    # search movie base.
    base = f"{os.getenv('TMDB_API_HOST')}/3/search/movie?api_key={os.getenv('TMDB_API_KEY')}&language=en-US&page=1&include_adult=false"

    # search movie extract year.
    pieces = title.split('(')
    if len(pieces) > 1:
        title = pieces[0]
        year  = pieces[1].split(')')[0]
    else:
        year  = None

    # search movie w/ year.
    if year is not None:
        r = requests.get(f"{base}&query={urllib.parse.quote(title)}&primary_release_year={year}")
    else:
        r = requests.get(f"{base}&query={urllib.parse.quote(title)}")

    # result[s] validate.
    if r.status_code != 200:
        return None

    # result[s] format.
    try:
        d = r.json()
        d = d['results'][0]
    except:
        return None

    # return.
    return d
