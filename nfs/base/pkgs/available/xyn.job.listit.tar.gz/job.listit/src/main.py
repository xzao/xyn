#
#   src/main.py
#
import glob
import logging
import os
import tmdb
import time


#
#   logging.
#
logging.basicConfig(level = logging.INFO)


#
#   config.
#
if os.path.isdir('/etc/listit'):
    logging.info("Configuration [/etc/listit] found.")
    if os.path.isfile('/etc/listit/processed'):
        with open('/etc/listit/processed') as fp:
            processed = [line.rstrip() for line in fp]
    else:
        processed = []
        with open('/etc/listit/processed', 'w') as fp: 
            pass


#
#   environmentals.
#
logging.info("Checking for environmentals.")
envs = [
    'TMDB_API_KEY',
    'TMDB_API_HOST',
    'TMDB_LIST_ID',
    'TMDB_USERNAME',
    'TMDB_PASSWORD'
]
for env in envs:
    if env not in os.environ:
        raise Exception(f"missing env: {env}")


#
#   start.
#
logging.info("Starting ...")
while True:


    #
    #   auth.
    #
    session_id = tmdb.auth()


    #
    #   process movies.
    #
    logging.info("Processing movie[s].")
    for folder in glob.glob("/movies/*"):

        # process, skip processed.
        if folder in processed:
            logging.info(f" -- [{folder}] :: Continuing, already processeed.")
            continue

        # process, mark processed.
        processed.append(folder)

        # process, search movie with tmdb.
        logging.info(f" -- [{folder}] :: Searching TMDB.")
        movie = tmdb.search_movie(os.path.basename(folder))

        # process, skip no results.
        if movie == None:
            logging.info(f" -- [{folder}] :: Continuing, no results found.")
            continue

        # process, result found.
        logging.info(f" -- [{folder}] :: Result found, movie [{movie['id']}]. ")

        # process, skip incorrect genre.
        if 'TMDB_GENRE_ID' in os.environ:
            genre_id = os.getenv('TMDB_GENRE_ID')
            if int(genre_id) not in movie['genre_ids']:
                logging.info(f" -- [{folder}] :: Continuing, movie [{movie['id']}] with genres {movie['genre_ids']} has no genre [{genre_id}]. ")
                continue

        # process, add to list.
        list_id = os.getenv('TMDB_LIST_ID')
        logging.info(f" -- [{folder}] :: Adding movie [{movie['id']}] to list [{list_id}].")
        if tmdb.add_movie_to_list(
            list_id  = list_id,
            movie_id = movie['id'],
            session_id = session_id
        ):
            logging.info(f" -- [{folder}] :: Added movie [{movie['id']}] to list [{list_id}].")
        else:
            logging.info(f" -- [{folder}] :: Adding movie [{movie['id']}] to list [{list_id}] [ERROR].")


    #
    #   save.
    #
    with open('/etc/listit/processed', 'w') as fp:
        fp.write('\n'.join(processed))


    #
    #   fin.
    #
    logging.info("Sleeping [3600].")
    time.sleep(3600)
