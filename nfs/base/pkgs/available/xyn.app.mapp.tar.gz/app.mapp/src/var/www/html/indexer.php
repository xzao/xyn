<?php


    function index_disk($path) {
        $packages = array();
        foreach( scandir($path) as $repo ){
            if( ! in_array($repo, IGNORE) ){
                $packages_enabled = NFS."/${repo}/pkgs/enabled";
                if( is_dir($packages_enabled) ){
                    foreach( scandir($packages_enabled) as $package_name ){
                        if( ! in_array($package_name, IGNORE) && strpos($package_name, 'app') !== false && $package_name != NAME ){
                            $package_path = "${packages_enabled}/${package_name}";
                            $package_name = explode('.', basename($package_path))[1];
                            $package = index_disk_package($package_path); 
                            if( $package === NULL ){ continue; }
                            $package['archive'] = basename($package_path).'.tar.gz';
                            $package['desc']    = index_disk_desc($package_path);
                            $package['name']    = $package_name;
                            $package['logo']    = index_disk_logo($package_name);
                            $package['path']    = $package_path;
                            $package['port']    = index_disk_port($package_path);
                            $package['repo']    = basename($repo);
                            $package['state']   = 'enabled';
                            if(   isset($package['colour']) ){
                                $package['colour-background']  = $package['colour'];
                            }
                            if(   isset($package['color']) ){
                                $package['colour-background']  = $package['color'];
                            }
                            if( ! isset($package['host']) ){
                                $package['host'] = HOST;
                            }
                            if( ! isset($package['link']) ){
                                $package['link'] = PROTOCOL.'://'.$package['host'].':'.$package['port'];
                            }
                            if( $package['style'] == 'dark' ){
                                $package['colour-text'] = '#CCCCCC';
                            }
                            $packages[] = $package;
                        }
                    }
                }

            }
        }
        return $packages;
    }

    function index_disk_desc($package) {
        $file = "${package}/DESC";
        if( is_file($file) ){
            $d = file_get_contents($file, 'r');
            $d = str_replace(array("\n","\r"), '<br />', $d);
            return $d;
        } else {
            return NULL;
        }
    }

    function index_disk_logo($package_name) {
        $logo = 'images/logos/fallback.png';
        if( is_file(ROOT."/images/logos/${package_name}.png") ){
            $logo = "images/logos/${package_name}.png";
        }
        return $logo;
    }

    function index_disk_package($path, $defaults = PACKAGE_DEFAULTS) {
        $file    = "${path}/app.json";
        $package = $defaults;
        if( file_exists($file) ){
            $json_string = file_get_contents($file);
            if( $json_string !== false ){ 
                $json = json_decode($json_string, true);
                if( $json !== null ){
                    $package = array_merge($package, $json);
                }
            }
        } else {
            return NULL;
        }
        return $package;
    }

    function index_disk_port($package) {
        $file = "${package}/bin/common";
        $search = 'PORT';
        if( is_file($file) ){
            $lines = file($file);
            foreach( $lines as $line ){
                if( strpos($line, $search) !== false ){
                    if( strpos($line, '=') !== false ){
                        $line = explode('=', $line)[1];
                    }
                    $port = filter_var($line, FILTER_SANITIZE_NUMBER_INT);
                    $port = str_replace('-', '', $port);
                    $port = substr($port, 0, 4);
                    return $port;
                }
            }
        } else {
            return NULL;
        }
    }

    function index_file($file) {
        $index_json_string = file_get_contents($file);
        if( $index_json_string === false ){ header('Location: error.html?status=501'); }
        $index_json = json_decode($index_json_string, true);
        if( $index_json === null ){ header('Location: error.html?status=501'); }
        return $index_json;
    }


?>
<?php


    // index apps.
    $apps = array();
    $file = ROOT.'/index.json';

    // index from file.
    if( file_exists($file) ){
        $apps = index_file($file);
    }

    // index from fs.
    if( count($apps) == 0 && isset($file) || PERSIST === false ){
        $apps = index_disk(NFS);
        if( PERSIST ){
            $json = json_encode($apps);
            file_put_contents($file, $json);
        }
    }

    // index apps sort.
    usort($apps, function ($item1, $item2) {
        return $item1['name'] <=> $item2['name'];
    });

    // debug.
    if( DEBUG ){
        echo '<pre>';
        echo '<h1>$_SERVER</h1>';
        print_r($_SERVER);
        echo '<hr />';
        echo '<h1>$apps</h1>';
        print_r($apps);
        echo '<hr />';
        die;
    }


?>
