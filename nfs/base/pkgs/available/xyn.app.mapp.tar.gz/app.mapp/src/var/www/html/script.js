

    // function[s].
    function getCardRowCount(card) {
        var width       = $('.card').first().width();
        var parentWidth = $('.card').first().offsetParent().width();
        var percent     = Math.round(100 * width / parentWidth);
        console.log(width);
        console.log(parentWidth);
        console.log(percent);
        if( 0 < percent && percent < 40 ){
            return 3;
        } else if( 40 < percent && percent < 60 ) {
            return 2;
        } else {
            return 1;
        }
    }
    function updatePage() {
        var cardRowCount = getCardRowCount();
        if( cardRowCount == 1 ){
            $("body").removeClass("desktop");
            $("body").removeClass("tablet");
            $("body").addClass("mobile");
            $(".card-desc").show();
            updateCardHoverEvents()
        } 
        if( cardRowCount == 2  ){
            $("body").removeClass("mobile");
            $("body").removeClass("desktop");
            $("body").addClass("tablet");
            $(".card-desc").show();
            updateCardHoverEvents()
        }
        if( cardRowCount == 3 ){
            $("body").removeClass("mobile");
            $("body").removeClass("tablet");
            $("body").addClass("desktop");
            $(".card-desc").show();
            updateCardHoverEvents()
        }
    }
    function updateCardHoverEvents() {
        if( $('body').hasClass('desktop') ){
            $(".card").unbind('mouseenter mouseleave');
            $(".card").hover(
                function(){
                    $(this).find(".card-content").removeClass('darken')
                },
                function(){
                    $(this).find(".card-content").addClass('darken');
                }
            );
        }
        if( $('body').hasClass('tablet') ){
            $(".card").unbind('mouseenter mouseleave');
            $(".card").hover(
                function(){
                    $(this).find(".card-content").removeClass('darken')
                },
                function(){
                    $(this).find(".card-content").addClass('darken');
                }
            );
        }
        if( $('body').hasClass('mobile') ){
            $(".card").hover(
                function(){
                    $(this).find(".card-content").removeClass('darken')
                },
                function(){
                    $(this).find(".card-content").addClass('darken');
                }
            );
        }
    }
    function updateCardSpacerHeights(height = undefined) {
        if( height != undefined ){
            $('.card-spacer').css('height', height + 'px');
        } else {
            var heightMax = -1;
            $('.card').each(function() {
                heightMax = heightMax > $(this).height() ? heightMax : $(this).height();
            });
            $('.card').each(function() {
                heightCurrent    = $(this).css('height').replace(/px/g,'');
                heightDifference = heightMax - heightCurrent;
                $(this).find('.card-spacer').css('height', heightDifference + 'px');
            });
        }
    }


    // card effect[s].
    $(document).ready(function() {
        updatePage();
    });
    $(window).resize(function() {
        updatePage();
    });


    // card select[s].
    $(document).ready(function() {

        // card select[ed].
        cardSelectedIndex = 0;
        cardSelectedMax   = $('.card').length - 1;

        // key[s].
        keyBack  =  8;
        keyEnter = 13;
        keyLeft  = 39;
        keyUp    = 38;
        keyRight = 37;
        keyDown  = 40;

        // mouse move reset.
        $(document).mousemove(function(event) {
            $('.card').removeClass("selected");
        });

        // key[s] press.
        $(document).keydown(function(event) {

            // row count.
            row_count = getCardRowCount();

            // navigate enter.
            if ( event.which == keyEnter ){
                event.preventDefault();
                console.log($('.card').eq(cardSelectedIndex).parent())
                $('.card').eq(cardSelectedIndex).click();
            }

            // navigate back.
            if ( event.which == keyBack ){
                event.preventDefault();
                window.history.back();
            }

            // navigate mobile.
            if( row_count == 1 || true ){

                // navigate mobile key up.
                if ( event.which == keyUp || event.which == keyRight ){
                    event.preventDefault();
                    if( cardSelectedIndex == 0 ){
                        cardSelectedIndex = cardSelectedMax
                    } else {
                        cardSelectedIndex --;
                    }
                    console.log(cardSelectedIndex);
                }

                // navigate mobile key down.
                if ( event.which == keyDown || event.which == keyLeft ){
                    event.preventDefault();
                    if( cardSelectedIndex == cardSelectedMax ){
                        cardSelectedIndex = 0
                    } else {
                        offset = -100
                        cardSelectedIndex ++;
                    }
                }

            }

            // navigate desktop/tablet.
            if( row_count > 1 && false ){
                
                if ( event.which == keyLeft ){
                    event.preventDefault();
                    if( cardSelectedIndex == 0 ){
                        cardSelectedIndex = cardSelectedMax
                    }
                    console.log(keyLeft)
                }
                
                if ( event.which == keyUp ){
                    event.preventDefault();
                    if( cardSelectedIndex == cardSelectedMax ){
                        cardSelectedIndex = 0
                    }
                    console.log(keyUp)
                }

                if ( event.which == keyRight ){
                    event.preventDefault();
                    if( cardSelectedIndex == cardSelectedMax ){
                        cardSelectedIndex = 0
                    }
                    console.log(keyRight)
                }

                if ( event.which == keyDown ){
                    event.preventDefault();
                    if( cardSelectedIndex == 0 ){
                        cardSelectedIndex = cardSelectedMax
                    }
                    console.log(keyDown)
                }

            }

            // navigate card selected.
            $('.card').not($('.card').eq(cardSelectedIndex)).removeClass("selected");
            $('.card').eq(cardSelectedIndex).addClass("selected")
            $('html, body').animate({
                scrollTop:  $('.card').eq(cardSelectedIndex).offset().top
            }, 200);

        });

    });
