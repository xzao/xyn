<?php require_once(__DIR__.'/config.php');  ?>
<?php require_once(__DIR__.'/indexer.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>

        <!-- title. -->
        <title><?php echo SITE; ?></title>

        <!-- meta. -->
        <meta name="viewport"    content="width=device-width, initial-scale=1">
        <meta name="description" content="<?php echo SITE; ?>">
        <meta name="theme-color" content="#1d1d1d">

        <!-- meta propertys. -->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta property="og:title"       content="<?php echo SITE; ?>">
        <meta property="og:type"        content="website">
        <meta property="og:url"         content="<?php echo HOST; ?>">
        <meta property="og:description" content="">
        <meta property="og:image"       content="image.png">

        <!-- font[s]. -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Karla:wght@700&display=swap" rel="stylesheet">

        <!-- link.
        <link rel="icon" href="http://xyn/favicon.ico">
        <link rel="icon" href="http://xyn/favicon.svg" type="image/svg+xml">
        <link rel="apple-touch-icon" href="http://xyn/apple-touch-icon.png"> -->
        <link rel="stylesheet" href="vendor/materialize.min.css">
        <link rel="stylesheet" href="styles.css">

    </head>
    <body>

        <!-- container -->
        <div class="page container">
            <div class="row">
                <?php foreach( $apps as $app ){ ?>

                    <!-- app -->
                    <div class="col s12 m12 l6 xl4">
                        <a href="<?php echo $app['link']; ?>">                        
                            <div class="card">
                                <div style="background-color: <?php echo $app['colour-background']; ?>" class="card-image darken">
                                    <img class="card-image-logo" src="<?php echo $app['logo']; ?>">
                                </div>
                                <div style="background-color: <?php echo $app['colour-background']; ?>; color: <?php echo $app['colour-text']; ?>" class="card-content darken">
                                    <div class="card-title"><?php echo $app['title']; ?></div>
                                    <p class="card-desc">
                                        <?php echo $app['desc']; ?>
                                    </p>
                                </div>
                                <div style="background-color: <?php echo $app['colour-background']; ?>" class="card-spacer"></div>
                            </div>
                        </a>
                    </div>

                <?php } ?>
            </div>
        <div>

        <!-- script[s]. -->
        <script src="vendor/jquery.min.js"></script>
        <script src="vendor/materialize.min.js"></script>
        <script src="script.js"></script>

    </body>
</html>
