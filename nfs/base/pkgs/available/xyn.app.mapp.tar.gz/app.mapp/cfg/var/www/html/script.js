

    // function[s].
    function getCardRowCount(card) {
        var width       = $(card).width();
        var parentWidth = $(card).offsetParent().width();
        var percent     = Math.round(100 * width / parentWidth);
        if( $( window ).width() > 1600 ){
            $('.page').addClass('container');
            return 3;
        } else {
            $('.page').removeClass('container');
        }
        if( 30 < percent && percent < 40 ){
            return 3;
        } else if( 40 < percent && percent < 60 ) {
            return 2;
        } else {
            return 1;
        }
    }
    function updatePage() {
        var cardRowCount = getCardRowCount($('.card').first());
        if( cardRowCount == 1 ){
            $("body").removeClass("desktop");
            $("body").removeClass("tablet");
            $("body").addClass("mobile");
            $(".card-desc").hide();
            updateCardHoverEvents()
        } 
        if( cardRowCount == 2  ){
            $("body").removeClass("mobile");
            $("body").removeClass("desktop");
            $("body").addClass("tablet");
            $(".card-desc").show();
            updateCardHoverEvents()
        }
        if( cardRowCount == 3 ){
            $("body").removeClass("mobile");
            $("body").removeClass("tablet");
            $("body").addClass("desktop");
            $(".card-desc").show();
            updateCardHoverEvents()
        }
    }
    function updateCardHoverEvents() {
        if( $('body').hasClass('desktop') ){
            $(".card").unbind('mouseenter mouseleave');
            $(".card").hover(
                function(){
                    $(this).find(".card-content").removeClass('darken-3')
                },
                function(){
                    $(this).find(".card-content").addClass('darken-3');
                }
            );
        }
        if( $('body').hasClass('mobile') ){
            $(".card").hover(
                function(){
                    $(this).find(".card-content").removeClass('darken-3')
                    $(this).find(".card-desc").show("slow");
                },
                function(){
                    $(this).find(".card-content").addClass('darken-3');
                    $(this).find(".card-desc").hide("slow");
                }
            );
        }
    }
    function updateCardSpacerHeights(height = undefined) {
        if( height != undefined ){
            $('.card-spacer').css('height', height + 'px');
        } else {
            var heightMax = -1;
            $('.card').each(function() {
                heightMax = heightMax > $(this).height() ? heightMax : $(this).height();
            });
            $('.card').each(function() {
                heightCurrent    = $(this).css('height').replace(/px/g,'');;
                heightDifference = heightMax - heightCurrent;
                $(this).find('.card-spacer').css('height', heightDifference + 'px');
            });
        }
    }


    // card effect[s].
    $(document).ready(function() {
        updatePage();
    });
    $(window).resize(function() {
        updatePage();
    });
