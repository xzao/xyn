<?php


    // global[s] flags.
    define( 'DEBUG',   false);
    define( 'PERSIST', false);


    // global[s] ssl.
    if( ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ){ $protocol = 'https'; } else { $protocol = 'http'; }

    // global[s].
    define( 'GIT',      'https://github.com/eyit/xyn.git'      );
    define( 'HOST',     explode(':', $_SERVER['HTTP_HOST'])[0] );
    define( 'IGNORE',   array('.', '..', '.gitignore')         );
    define( 'NFS',      '/opt/xyn/nfs'                         );
    define( 'NAME',     'app.mapp'                             );
    define( 'PROTOCOL', $protocol                              ); 
    define( 'ROOT',     __DIR__                                );
    define( 'SITE',     'XYN'                                  );

    // global[s] package defaults.
    define( 'PACKAGE_DEFAULTS', array(
        'color' => 'white',
        'logo'  => 'images/logos/fallback.png'
    ));

    
?>
