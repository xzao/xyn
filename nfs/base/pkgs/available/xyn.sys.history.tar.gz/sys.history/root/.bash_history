blkid
cat /etc/fstab 
cd
cd ../
cd /boot/
cd /opt/xyn
df -h
docker
docker ps -a
exit
fdisk -l
icanhazip
ip addr
ls
ls -lah
ping google.com
pwd
reboot
systemctl start   docker.service
systemctl stop    docker.service
systemctl enable  docker.service
systemctl disable docker.service
systemctl start   mediacenter.service
systemctl stop    mediacenter.service
systemctl disable mediacenter.service
vim .ssh/authorized_keys
